import matplotlib.pyplot as plt
from statistics import mean,stdev,median
import csv
import math
import numpy as np
import pickle
# from pyod.models.ocsvm import OCSVM
# from pyod.models.pca import PCA 
from sklearn.metrics import roc_auc_score
from sklearn.svm import OneClassSVM as oc_svm 

# file2 = open('non_malicious_timestamps','wb')
# # pickle.dump(non_malicious_timestamps,file2)
file2 = open('non_malicious_timestamps','rb')
non_malicious_timestamps = pickle.load(file2)

file2 = open('malicious_timestamps','rb')
malicious_timestamps = pickle.load(file2)

# file2 = open('malicious_timestamps','wb')
# pickle.dump(malicious_timestamps,file2)

file2 = open('non_malicious','rb')
non_malicious = pickle.load(file2)

file2 = open('malicious','rb')
mal_traders = pickle.load(file2)

file = open('data_normal','rb')
normal_complete_data_arr = pickle.load(file)

file = open('data_mal','rb')
malicious_complete_data_arr = pickle.load(file)

all_labels = []

all_data = np.vstack((normal_complete_data_arr,malicious_complete_data_arr))

for i in range(len(all_data)):
    if i < len(normal_complete_data_arr):
        all_labels.append(1)
    else:
        all_labels.append(-1)
# print(all_labels.count(1))        
## train_Data
# print(0.8*len(normal_complete_data_arr))
train_normal_arr = normal_complete_data_arr[0:int(0.8*len(normal_complete_data_arr))]
# train_mal_arr = 
test_normal_arr =  normal_complete_data_arr[int(0.8*len(normal_complete_data_arr)):len(normal_complete_data_arr)]

test_all_data = np.vstack((test_normal_arr,malicious_complete_data_arr))

train_normal_arr_stnd_2 = train_normal_arr - train_normal_arr.mean(axis = 0)
# negatives_mat = negatives_mat - negatives_mat.mean(axis =0)
# all_data_mat = all_data_mat - all_data_mat.mean(axis=0)

train_normal_arr_stnd = train_normal_arr_stnd_2/(train_normal_arr_stnd_2.std(axis = 0)+1)

# test_all_data_stnd = test_all_data - test_all_data.mean(axis = 0)
test_all_data_stnd = test_all_data - train_normal_arr.mean(axis = 0)
# negatives_mat = negatives_mat - negatives_mat.mean(axis =0)
# all_data_mat = all_data_mat - all_data_mat.mean(axis=0)

test_all_data_stnd = test_all_data_stnd/(train_normal_arr_stnd_2.std(axis = 0)+1)
## Generate labels

all_feature_vector = np.vstack((train_normal_arr_stnd,test_all_data_stnd))
# normal_complete_data_arr = all_data[0:len(normal_complete_data_arr)]
# test_labels = all_labels[int(0.8)*len(normal_complete_data_arr):len(all_labels)]
train_labels = all_labels[0:int(0.8*len(normal_complete_data_arr))] 
test_labels = all_labels[int(0.8*len(normal_complete_data_arr)):len(all_labels)]
# clf1 = PCA(n_components = 15,n_selected_components = 3)
# clf1.fit(train_normal_arr_stnd)
# predicted = clf1.predict(test_all_data_stnd)
# accuracy = 0
# recall = 0
# print(clf1.components_)
# for i in range(len(predicted)):
#     if predicted[i] == test_labels[i] and test_labels[i] == 1:
#         recall +=1
#     if predicted[i] == all_labels[i]:
#         accuracy +=1
# print("PCA Accuracy",accuracy/len(train_normal_arr_stnd))
# print("PCA Recall",recall/len(malicious_complete_data_arr))
# print(clf1.singular_values_)
test_keys = non_malicious[int(0.8*len(normal_complete_data_arr)):len(all_labels)] + mal_traders
def sigmoid(x):
  return 1 / (1 + math.exp(x))

## OCSVM
# clf1 = OCSVM(kernel = 'rbf',gamma = 1,nu = 0.4)
clf1 = oc_svm(kernel = 'rbf',nu= 0.03,gamma = 0.1)
clf1.fit(train_normal_arr_stnd)
roc = []
recall_list = []

# clf1.threshold_ = i
predicted = clf1.predict(test_all_data_stnd)


# print(predicted)
print(clf1.score_samples(test_all_data_stnd))
score_test = clf1.score_samples(test_all_data_stnd)
print("min score:%f and max score:%f"%(min(score_test),max(score_test)))
min_score_test = min(score_test)
max_score_test = max(score_test)
# print(test_labels)
# for k in np.arange(-0.01,0.01,0.0005):
# print("for",k)
from sklearn.metrics import roc_curve, auc
roc_auc = []
fpr_list = []
tpr_list = []
fpr_list.append(0.0)
tpr_list.append(0.0)
data_thresh = []
data_to_show = []
for k in np.arange(min_score_test,max_score_test,0.05):    
    predicted = []
    for val in range(len(test_all_data_stnd)):
        # print(clf1.score_samples(test_all_data_stnd[val].reshape(1,-1)))
        if clf1.score_samples(test_all_data_stnd[val].reshape(1,-1)) > k:
            predicted.append(1)
        else:
            predicted.append(-1)

    accuracy = 0
    recall = 0
    indices = []
    indices_positive = 0
    indices_negative = 0
    pred_indices_mal = []
    for i in range(len(predicted)):
        if predicted[i] == test_labels[i]:
            accuracy +=1
        if predicted[i] == test_labels[i] and test_labels[i] == -1:
            recall +=1
            indices.append(i)
        if predicted[i] == -1:
            pred_indices_mal.append(i)
            indices_positive +=1
        if predicted[i] == 1:
            # pred_indices_mal.append(i)
            indices_negative +=1
        
    precision = recall/indices_positive
    # print("OCSVM Precision",100*precision)
    # print("OCSVM accuracy",100*accuracy/len(test_labels))
    # print("OCSVM recall",100*recall/len(malicious_complete_data_arr))
    # print("f measure", ((precision*recall)/(precision+recall)))
    # print(len(clf1.support_vectors_))
    # print(clf1.score_samples(test_all_data_stnd))
    # print(len(clf1.decision_scores_[clf1.decision_scores_>clf1.threshold_])) 
    try: 
        roc.append(roc_auc_score(predicted,test_labels))
        fpr, tpr, _ = roc_curve(test_labels,predicted)
        true_pos_rate = recall/len(malicious_complete_data_arr)
        false_positive = indices_positive - recall
        true_negative = len(normal_complete_data_arr) -  false_positive
        true_negative = indices_negative - (len(malicious_complete_data_arr) - recall)
        false_pos_rate = false_positive/(false_positive +true_negative) 
        # print(len(clf1.support_vectors_))
        roc_auc.append(auc(fpr, tpr))
        fpr_list.append(false_pos_rate)
        tpr_list.append(true_pos_rate)
        #  fpr_list.append(fpr[1])
        # tpr_list.append(tpr[1])
        recall_list.append(recall)
        print("roc",roc_auc_score(predicted,test_labels))
        data_thresh.append([k,100*precision,100*recall/len(malicious_complete_data_arr),100*accuracy/len(test_labels),roc_auc_score(predicted,test_labels)])
        data_to_show.append([round(k,5),round(100*precision),round(100*recall/len(malicious_complete_data_arr),3),round(100*accuracy/len(test_labels),3),round(roc_auc_score(predicted,test_labels),3)])
    	
    except:
        roc.append(0)
        recall_list.append(0)
        pass
score = clf1.score_samples(test_all_data_stnd)
severity = []
for val in score:
    severity.append(sigmoid((0.0001 - val)*(10**4)))
severity_cto = []
from collections import Counter
traders_mal = []
for i in range(len(pred_indices_mal)):
    traders_mal.append(test_keys[pred_indices_mal[i]])
    severity_cto.append(severity[pred_indices_mal[i]])
data_thresh.sort(key = lambda i:(i[4],i[2]),reverse = True)
# print(data_thresh)
data_thresh = np.asarray(data_thresh)
# print(data_to_show)
# print(roc)
# result = Counter(traders_mal)
# [item for items, c in Counter(traders_mal).most_common() 
                                      # for item in [items] * c]
# print(severity)
with open('roc_values.txt','w') as f:
    f.writelines("%s \n" %('[threshold prec recall accuracy auc]'))
    f.writelines("%s \n" % val for val in data_thresh)

severity_cto = np.asarray(severity_cto)
severity_cto = severity_cto/max(severity_cto)

fpr_list.append(1.0)
tpr_list.append(1.0)
fpr_arr = np.asarray(fpr_list)
tpr_arr = np.asarray(tpr_list)
data_to_show_arr = np.asarray(data_to_show)
# print(data_to_show_arr[0,0])
plt_threshold = data_to_show_arr[:,0]
plt_roc = data_to_show_arr[:,4]
plt_recall = data_to_show_arr[:,2]
# plt.plot(plt_threshold,plt_roc)
# tpr_arr = [0.0,tpr_arr,1.0]
# fpr_arr = [0.0,fpr_arr,1.0]
# print(fpr_arr)
# print(tpr_arr)
plt.plot(fpr_arr,tpr_arr)
plt.show()

fpr_tpr_data = np.hstack((fpr_arr,tpr_arr))
roc_thresh_data = np.hstack((plt_threshold,plt_roc))
recall_thresh_data = np.hstack((plt_threshold,plt_recall))
import pickle
file = open('thresh_roc','wb')
pickle.dump(roc_thresh_data,file)

file = open('fpr_tpr','wb')
pickle.dump(fpr_tpr_data,file)

file = open('thresh_recall','wb')
pickle.dump(recall_thresh_data,file)


# print()
# print(len(test_all_data_stnd))
# print(len(indices)/len(test_all_data_stnd))
# print(len(pred_indices_mal))
# print(indices_positive)
cto_input = []
for i in range(len(traders_mal)):
    cto_input.append([traders_mal[i],'layer',severity_cto[i]])
cto_sort = cto_input.sort()
# print(cto_input)
# print(predicted)
# print(test_labels)
# for index in indices:
#     print(malicious_keys[int(index-0.2*len(normal_complete_data_arr))])
# print(len(test_all_data_stnd))
# print(len(indices)/len(test_all_data_stnd))

# print(max(roc))
# fig1,ax1 = plt.subplots(1,1)
# print(len(roc))
# ax1.scatter(np.arange(len(recall_list)),recall_list)
# # ax2.scatter(np.arange(len(clf1.decision_scores_)),clf1.decision_scores_)
# plt.show()
# print(indices_positive/len(test_labels))

# for i in range(n_classes):
# test_labels[test_labels==-1] = 0
# test_labels[test_labels==1] = -1
# test_labels[test_labels==0] = 1
# predicted[predicted==-1] = 0
# predicted[predicted==1] = -1
# predicted[predicted==0] = 1
# fpr, tpr, _ = roc_curve(test_labels,predicted)
# roc_auc = auc(fpr, tpr)
# print(fpr,tpr,_)
# plt.figure()
# lw = 2
# print(len(fpr_list))
# for i in range(len(fpr_list)):
#     if not i:
#         plt.plot(0.0, 0.0,'ro-')
#     else:
#         plt.scatter(fpr_list[i], tpr_list[i], 'ro-')
# plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
# plt.xlim([0.0, 1.0])
# plt.ylim([0.0, 1.05])
# plt.xlabel('False Positive Rate / Recall(here)')
# plt.ylabel('True Positive Rate')
# plt.title('Receiver operating characteristic example')
# # plt.legend(loc="lower right")
# plt.show()
